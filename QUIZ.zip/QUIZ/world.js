const container=document.querySelector('.container')
const questionbox=document.querySelector('.question')
const choicesbox=document.querySelector('.choices')
const nextbtn=document.querySelector('.nxtbtn')
const scorecard=document.querySelector('.scorecard')
const alert=document.querySelector('.alert')
let timer=document.querySelector('.timer')
let h4=document.querySelector('h4')
let timeleft=20
const quiz=[
    {
        question:"Q1:Which is the headquarters of the Office of the United Nations High Commissioner for Human Rights (OHCHR)?",
        choices:["New York",
             "Geneva",
             "Paris",
             "Nairobi"],
        answer:"Geneva"
    },
    {
        question:"Q2:With which country's highest award, the Grand Cross of the Legion of Honour, was PM Modi conferred?",
        choices:["Russia",
            "Oman",
            "France",
            "Denmark"],
        answer:"France"
    },
    {
        question:"Q3:Which country's parliament approved a bill to limit the Supreme Court's power?",
        choices:["India","France","Germany","Israel"],
        answer:"Israel"
    },
    {
        question:"Q4:With which country has the Indian government signed an agreement to operationalize UPI (Unified Payment Interface)?",
        choices:["France","Belgium","Australia","UAE"],
        answer:"France"
    },
    {
        question:"Q5:Which country received final IMF approval for a USD 3-billion loan under a stand-by arrangement?",
        choices:["China","Pakistan","Japan","France"],
        answer:"Pakistan"
    },
    {
        question:"Q6:Netherlands Prime Minister Mark Rutte announced to quit politics. Which is the capital of the Netherlands?",
        choices:["Amsterdam","Chile","Rotterdam","The Hague"],
        answer:"Amsterdam"
    },
    {
        question:"Q7:According to Global Firepower, which country has the world's most powerful military?",
        choices:["China","USA","Russia","India"],
        answer:"USA"
    },
    {
        question:"Q8:What is the official mascot of the Asian Athletics Championships, Thailand?",
        choices:["Lord Ganesha","Lord Hanuman","Lord Shiv","Lord Rama"],
        answer:"Lord Hanuman"
    }, {
        question:"Q9:In which country have scientists discovered a hidden passage inside the Great Pyramid?",
        choices:["Egypt","Syria","Chile","Sudan"],
        answer:"Egypt"
    },
    {
        question:"Q10Which country launched a probe into the alleged leak of Ukraine war files?",
        choices:["China","Russia","Iran","USA"],
        answer:"USA"
    }

];


let timerid=null
let currentquestionindex=0
let score=0;
//showquestion
const showquestions=()=>{
    let select=0;
const quesdetails=quiz[currentquestionindex]
questionbox.textContent=quesdetails.question
choicesbox.textContent=""
for(let i=0;i<quesdetails.choices.length;i++){
    const currentchoice=quesdetails.choices[i];
    const choicediv=document.createElement('div')
    choicediv.classList.add("choice")
    choicediv.textContent=currentchoice;
    choicesbox.appendChild(choicediv);
    choicediv.addEventListener('click',()=>{
      if(select==0)
      { choicediv.classList.add('selected')
      select++

      }
     
    })
}
if(currentquestionindex<quiz.length){
    starttimer();
}
}
//starttimer
const starttimer=()=>{
    clearInterval(timerid)
    const countdown=()=>{
       if(timeleft===-1){
        const confirmuser= confirm("You need to play again!")
        if (confirmuser){
            currentquestionindex=0;
            score=0
            startquiz()
            
            timeleft=20
        }
        else{
            
            return;
            
        }
       }
        timer.textContent=timeleft
        timeleft--
    }
   timerid=setInterval(countdown,1000)
    }



//checkanswer
const checkanswer=()=>{
    const selectedchoice=document.querySelector('.choice.selected');
    if(selectedchoice.textContent===quiz[currentquestionindex].answer){
        alert.style.backgroundColor="green"
      displayalert("Yes its right!")
        score++
    }
    else{
        alert.style.backgroundColor="red"
        displayalert(`Oops! Wrong answer  (${quiz[currentquestionindex].answer} is the correct answer)`)
    }
    timeleft=20
 currentquestionindex++;
    if(currentquestionindex<quiz.length){
       
        showquestions();
       
    }
    else{
        showscore();
        stoptimer();
    }
}

//function to show score
const showscore=()=>{
    questionbox.textContent=""
    choicesbox.textContent=""
    timer.textContent=""
    h4.textContent=""
    scorecard.textContent=`You have  scored ${score} marks out of ${quiz.length}`;
    displayalert("You have completed your quiz")
    nextbtn.textContent="Thank You for trying!"
}
//function to stop timer

const stoptimer=()=>{
    clearInterval(timerid)
}

const displayalert=(msg)=>{
    alert.style.display="block"
    alert.textContent=msg;

    setTimeout(()=>{
        alert.style.display="none"
       
    
    },2000)
    }

   const startquiz=()=>{
    showquestions();
   }
startquiz()
nextbtn.addEventListener('click',()=>{
  checkanswer()
  
})

