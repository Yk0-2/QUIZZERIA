const container=document.querySelector('.container')
const questionbox=document.querySelector('.question')
const choicesbox=document.querySelector('.choices')
const nextbtn=document.querySelector('.nxtbtn')
const scorecard=document.querySelector('.scorecard')
const alert=document.querySelector('.alert')
let timer=document.querySelector('.timer')
let h4=document.querySelector('h4')
let timeleft=20

const quiz=[
    {
        question:"Q1:Which state is called land of 5 rivers?",
        choices:["Odisha","Himachal Pradesh","Punjab","J&K"],
        answer:"Punjab"
    },
    {
        question:"Q2:Which is the highest rail bridge in the world?",
        choices:["Shimla","Howrah","Darjeling","Chenab"],
        answer:"Chenab"
    },
    {
        question:"Q3:Who is the president of Republic of India?",
        choices:["Amit Shah","Draupadi Murmu","Rajendra Prasad","Ram Nath Kovind"],
        answer:"Draupadi Murmu"
    },
    {
        question:"Q4:How many states and Uts India consist of?",
        choices:["28 and 8","28 and 7","29 and 4","27 and 8"],
        answer:"28 and 8"
    },
    {
        question:"Q5:Indian Navy conducted Maratime Partnership with Which country in Andaman&Nicobar islands?",
        choices:["China","Pakistan","Japan","France"],
        answer:"Japan"
    },
    {
        question:"Q6:What is BRO?",
        choices:["Border Road Organisation","Border Reservation Operation","Boundary Operation Reservoir","Border Road Operatabilty"],
        answer:"Border Road Organisation"
    },
    {
        question:"Q7:What was the Budget of Chandrayan 3?",
        choices:["600Cr","800Cr","650Cr","500Cr"],
        answer:"650Cr"
    },
    {
        question:"Q8:India last hosted The Cricket World Cup in which year?",
        choices:["2021","2018","2007","2011"],
        answer:"2011"
    }, {
        question:"Q9:When next Lok Sabha Elections in INDIA are going to be held?",
        choices:["2025","2024","2030","2026"],
        answer:"2024"
    },
    {
        question:"Q10:Which is the Oldest University of India?",
        choices:["Nalanda University","JNU","Punjabi University","Kilimanjaro University"],
        answer:"Nalanda University"
    }

];

let timerid=null
let currentquestionindex=0
let score=0;
//showquestion
const showquestions=()=>{
    let select=0;
const quesdetails=quiz[currentquestionindex]
questionbox.textContent=quesdetails.question
choicesbox.textContent=""
for(let i=0;i<quesdetails.choices.length;i++){
    const currentchoice=quesdetails.choices[i];
    const choicediv=document.createElement('div')
    choicediv.classList.add("choice")
    choicediv.textContent=currentchoice;
    choicesbox.appendChild(choicediv);
    choicediv.addEventListener('click',()=>{
      if(select==0)
      { choicediv.classList.add('selected')
      select++

      }
     
    })
}
if(currentquestionindex<quiz.length){
    starttimer();
}
}
//starttimer
const starttimer=()=>{
    clearInterval(timerid)
    const countdown=()=>{
       if(timeleft===-1){
        const confirmuser= confirm("You need to play again!")
        if (confirmuser){
            currentquestionindex=0;
            score=0
            startquiz()
            
            timeleft=20
        }
        else{
            
            return;
            
        }
       }
        timer.textContent=timeleft
        timeleft--
    }
   timerid=setInterval(countdown,1000)
    }



//checkanswer
const checkanswer=()=>{
    const selectedchoice=document.querySelector('.choice.selected');
    if(selectedchoice.textContent===quiz[currentquestionindex].answer){
        alert.style.backgroundColor="green"
      displayalert("Yes its right!")
        score++
    }
    else{
        alert.style.backgroundColor="red"
        displayalert(`Oops! Wrong answer  (${quiz[currentquestionindex].answer} is the correct answer)`)
    }
    timeleft=20
 currentquestionindex++;
    if(currentquestionindex<quiz.length){
       
        showquestions();
       
    }
    else{
        showscore();
        stoptimer();
    }
}

//function to show score
const showscore=()=>{
    questionbox.textContent=""
    choicesbox.textContent=""
    timer.textContent=""
    h4.textContent=""
    scorecard.textContent=`You have  scored ${score} marks out of ${quiz.length}`;
    displayalert("You have completed your quiz")
    nextbtn.textContent="Thank You for trying!"
}
//function to stop timer

const stoptimer=()=>{
    clearInterval(timerid)
}


const displayalert=(msg)=>{
    alert.style.display="block"
    alert.textContent=msg;

    setTimeout(()=>{
        alert.style.display="none"
       
    
    },2000)
    }

   const startquiz=()=>{
    showquestions();
   }
startquiz()
nextbtn.addEventListener('click',()=>{
  checkanswer()
  
})
