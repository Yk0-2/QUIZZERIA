

const container=document.querySelector('.container')
const questionbox=document.querySelector('.question')
const choicesbox=document.querySelector('.choices')
const nextbtn=document.querySelector('.nxtbtn')
const scorecard=document.querySelector('.scorecard')
const alert=document.querySelector('.alert')
let timer=document.querySelector('.timer')
let h4=document.querySelector('h4')
let timeleft=20

const quiz=[
    {
        question:"Q1:What is the value of iota?",
        choices:['1','-1','underoot(1)','underoot(-1)'],
        answer:"underoot(-1)"
    },
    {
        question:"Q2:Ram weighs 25kg more than Shyam.Their combined weight is 325kg.What is weight of Shayam?",
        choices:['150kg','180kg','190kg','None of the above'],
        answer:'150kg'
    },
    {
        question:"Q3:Is Zero a whole number or a natural number?",
        choices:['Whole number','Natural number','Neither of them','Both of them'],
        answer:"Whole number"
    },
    {
        question:"Q4:What is derivative of Sec x?",
        choices:["Sec x","Tan x","Sec x Tan x","Tan(1/x)"],
        answer:"Sec x Tan x"
    },
    {
        question:"Q5:If a=3+i b=2-2i then find out a*b?",
        choices:['8+i','8-4i','8-i','8+4i'],
        answer:"8-4i"
    },
    {
        question:"Q6:What is value of tan 30?",
        choices:['1/underoot(3)','underoot(3)','1/2','1'],
        answer:"1/underoot(3)"
    },
    {
        question:"Q7:Who invented ZERO?",
        choices:['Shakuntla Devi' ,'Ramanunjan', 'Aryabhatta', 'Albert Einstein'],
        answer:"Aryabhatta"
    },
    {
        question:"Q8:What does PythagorusTheorem state?",
        choices:["The sum of angles of a right angled triangle is 180 degree","The area of circle is pie times the square of perimeter","Sides of triangle can never be equal","The square of hypotenuse of triangle is equal to sum of squares of other two sides"],
        answer:"The square of hypotenuse of triangle is equal to sum of squares of other two sides"
    }, {
        question:"Q9:What is slope of a horizontal and vertical line?",
        choices:['0 and undefined' ,'undefined and 1' ,'1 and undefined' ,'1/2 and 1'],
        answer:"0 and undefined"
    },
    {
        question:"Q10:What is integral of 1?",
        choices:['0','1','x','undefined'],
        answer:"x"
    }

];


let timerid=null
let currentquestionindex=0
let score=0;
//showquestion
const showquestions=()=>{
    let select=0;
const quesdetails=quiz[currentquestionindex]
questionbox.textContent=quesdetails.question
choicesbox.textContent=""
for(let i=0;i<quesdetails.choices.length;i++){
    const currentchoice=quesdetails.choices[i];
    const choicediv=document.createElement('div')
    choicediv.classList.add("choice")
    choicediv.textContent=currentchoice;
    choicesbox.appendChild(choicediv);
    choicediv.addEventListener('click',()=>{
      if(select==0)
      { choicediv.classList.add('selected')
      select++

      }
     
    })
}
if(currentquestionindex<quiz.length){
    starttimer();
}
}
//starttimer
const starttimer=()=>{
    clearInterval(timerid)
    const countdown=()=>{
       if(timeleft===-1){
        const confirmuser= confirm("You need to play again!")
        if (confirmuser){
            currentquestionindex=0;
            score=0
            startquiz()
            
            timeleft=20
        }
        else{
            
            return;
            
        }
       }
        timer.textContent=timeleft
        timeleft--
    }
   timerid=setInterval(countdown,1000)
    }



//checkanswer
const checkanswer=()=>{
    const selectedchoice=document.querySelector('.choice.selected');
    if(selectedchoice.textContent===quiz[currentquestionindex].answer){
        alert.style.backgroundColor="green"
      displayalert("Yes its right!")
        score++
    }
    else{
        alert.style.backgroundColor="red"
        displayalert(`Oops! Wrong answer  (${quiz[currentquestionindex].answer} is the correct answer)`)
    }
    timeleft=20
 currentquestionindex++;
    if(currentquestionindex<quiz.length){
       
        showquestions();
       
    }
    else{
        showscore();
        stoptimer();
    }
}

//function to show score
const showscore=()=>{
    questionbox.textContent=""
    choicesbox.textContent=""
    timer.textContent=""
    h4.textContent=""
    scorecard.textContent=`You have  scored ${score} marks out of ${quiz.length}`;
    displayalert("You have completed your quiz")
    nextbtn.textContent="Thank You for trying!"
}
//function to stop timer

const stoptimer=()=>{
    clearInterval(timerid)
}

const displayalert=(msg)=>{
    alert.style.display="block"
    alert.textContent=msg;

    setTimeout(()=>{
        alert.style.display="none"
       
    
    },2000)
    }

   const startquiz=()=>{
    showquestions();
   }
startquiz()
nextbtn.addEventListener('click',()=>{
  checkanswer()
  
})
